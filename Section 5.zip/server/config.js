module.exports = {
  database:
    'mongodb://arash:abc123@ds111638.mlab.com:11638/amazonowebapplication',
  port: 3030,
  secret: 'ArashYahaya2012312321'
};
